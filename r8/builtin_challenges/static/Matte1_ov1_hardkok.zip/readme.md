# Good to know
- Hvis OS fortsetter å slette filen er det lurt å skru av Anti-Virus, eller starte opp en VM avhening av hvor mye dere stoler på meg
- Word 2020+ gir ikke mulighet for å se bildenavn: Bossman = adaopiwer og doggo = pelxcitrdd
- For alle som ikke har tilgang til powershell kan dette enten [lastes ned](https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell?view=powershell-7.2) eller bruke [online playground](https://code.labstack.com/powershell) (kan være ustødig)

