# Good to know
- Hvis OS fortsetter å slette filen er det lurt å skru av Anti-Virus, eller starte opp en VM avhening av hvor mye dere stoler på meg
- Word 2019+ gir ikke mulighet for å se bildenavn: Bossman = adaopiwer og doggo = pelxcitrdd
